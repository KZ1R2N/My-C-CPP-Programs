# Personal-Data-Security-System
This is my first year project.

******* Warning *******
Don't enter garbage value, it can delete your valuable data from C: drive.
